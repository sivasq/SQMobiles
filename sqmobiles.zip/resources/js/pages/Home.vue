<template>
  <div class="container">
    <div class="card card-default">
      <div class="card-header">Home</div>
      <div class="card-body">
        <h1>Welcome to SQIndia</h1>
      </div>
    </div>
  </div>
</template>
