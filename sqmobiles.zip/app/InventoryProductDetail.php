<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InventoryProductDetail extends Model
{
    protected $guarded = ['id'];
}
